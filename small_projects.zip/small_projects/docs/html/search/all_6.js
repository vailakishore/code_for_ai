var searchData=
[
  ['var_0',['var',['../num__conversion_8c.html#a96c77f9f3a7baec84b9b8add26a31787',1,'num_conversion.c']]]
];
