import pickle
import graphviz
import os

# Define the FunctionNode class to match your data structure
class FunctionNode:
    def __init__(self, name, params, file, line, code, file_path=None):
        self.name = name
        self.params = params
        self.file = file
        self.line = line
        self.code = code
        self.file_path = file_path
        self.called_functions = []  # This should be populated with the names of called functions
        self.local_variables = []

def load_function_tree(pickle_file):
    try:
        with open(pickle_file, 'rb') as f:
            return pickle.load(f)
    except EOFError:
        print(f"Error: The pickle file {pickle_file} is empty or corrupted.")
        return None

def generate_function_graph(function_nodes, output_path):
    # Create a directed graph object using graphviz
    dot = graphviz.Digraph(comment='Function Call Graph', format='png')

    # Add nodes and edges for each function in the function tree
    for node in function_nodes:
        # Use function name and file as the node label
        label = f"{node.name}\n{node.file}:{node.line}"
        dot.node(node.name, label)

        # Create edges for each function that this function calls
        for called_func in node.called_functions:
            # Ensure the called function exists before creating the edge
            dot.edge(node.name, called_func)

    # Render the graph to a PNG file
    output_png = dot.render(output_path)
    print(f"Graph saved as {output_png}")

# Path to the pickle file and where to save the output PNG
pickle_file_path = r'D:/code/small_projects/output_floder/function_tree.pkl'
output_png_path = r'D:/code/small_projects/output_floder/function_call_graph'

# Load the function tree from the pickle file
function_nodes = load_function_tree(pickle_file_path)

if function_nodes:
    # Generate the function call graph and save it as a PNG
    generate_function_graph(function_nodes, output_png_path)
else:
    print("No function nodes to process.")
