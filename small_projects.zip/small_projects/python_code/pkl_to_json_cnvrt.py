import os
import pickle
import json

class FunctionNode:
    def __init__(self, name, params, file, line, code, file_path=None):
        self.name = name
        self.params = params
        self.file = file
        self.line = line
        self.code = code
        self.file_path = file_path
        self.called_functions = []  # Function names this function calls
        self.local_variables = []

# Path to the pickle file and output JSON file
pickle_file_path = r'D:/code/small_projects/output_floder/function_tree.pkl'
json_file_path = r'D:/code/small_projects/output_floder/function_call_graph.json'
updated_json_file_path = r'D:/code/small_projects/output_floder/updated_function_call_graph.json'

# Function to serialize FunctionNode to a dictionary for JSON output
def serialize_function_node(node):
    return {
        'name': node.name,
        'file': node.file,
        'line': node.line,
        'called_functions': node.called_functions
    }

# Load the pickle file
def load_function_tree(pickle_file):
    try:
        with open(pickle_file, 'rb') as f:
            return pickle.load(f)
    except EOFError:
        print(f"Error: The pickle file {pickle_file} is empty or corrupted.")
        return None

# Save function tree to a JSON file
def save_function_tree_to_json(function_nodes, json_file):
    json_data = [serialize_function_node(node) for node in function_nodes]
    
    # Save JSON data to file
    with open(json_file, 'w') as f:
        json.dump(json_data, f, indent=4)
    
    print(f"Function call tree saved to {json_file}")

# Find the correct file path
def find_file(root_path, filename):
    """Recursively searches for a file within the given root path."""
    for dirpath, dirnames, filenames in os.walk(root_path):
        if filename in filenames:
            return os.path.join(dirpath, filename)
    return None

# Update JSON file with correct file paths
def update_json_with_actual_paths(json_data, root_path):
    """Updates the 'file' fields in the JSON data with the correct file paths."""
    for function_node in json_data:
        original_file_path = function_node['file']
        # Extract the filename from the original file path
        filename = os.path.basename(original_file_path)
        # Find the actual file path by searching from the root directory
        actual_file_path = find_file(root_path, filename)
        
        if actual_file_path:
            # If the file is found, update the path in the JSON data
            function_node['file'] = actual_file_path
        else:
            print(f"File not found for: {original_file_path}")

# Main function to merge everything
def main():
    # Load function tree from the pickle file
    function_nodes = load_function_tree(pickle_file_path)

    # If successfully loaded, save it to JSON first
    if function_nodes:
        save_function_tree_to_json(function_nodes, json_file_path)
    else:
        print("No function nodes found in the pickle file.")
        return

    # Load the generated JSON file
    with open(json_file_path, 'r') as json_file:
        json_data = json.load(json_file)

    # User-provided root path where files are located
    root_path = input("Enter the root directory path: ")

    # Update JSON data with actual file paths
    update_json_with_actual_paths(json_data, root_path)

    # Save the updated JSON file
    with open(updated_json_file_path, 'w') as json_file:
        json.dump(json_data, json_file, indent=4)
    
    print(f"Updated JSON file saved to: {updated_json_file_path}")

if __name__ == "__main__":
    main()
