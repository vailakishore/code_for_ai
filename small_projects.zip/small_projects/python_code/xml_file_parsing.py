import xml.etree.ElementTree as ET
import pickle
import os
import graphviz

class FunctionNode:
    def __init__(self, name, params, file, line, code, file_path=None):
        self.name = name
        self.params = params
        self.file = file
        self.line = line
        self.code = code
        self.file_path = file_path
        self.called_functions = []  # Function names this function calls
        self.local_variables = []

def parse_file_xml(xml_file):
    tree = ET.parse(xml_file)
    root = tree.getroot()

    function_nodes = []
    
    # Locate the file path
    location_element = root.find('.//compounddef/location')
    if location_element is not None:
        file_path = location_element.get('file')
    else:
        print(f"No location element found in {xml_file}")
        return function_nodes  # Skip if no location element found

    if not file_path:
        print(f"No file path found in {xml_file}")
        return function_nodes  # Skip if no file path found

    # Parse the XML for function definitions in this file
    for memberdef in root.findall('.//memberdef[@kind="function"]'):
        name = memberdef.find('name').text
        params = [param.text for param in memberdef.findall('.//param/defname')]
        file = file_path
        line = memberdef.find('location').get('line')
        code = memberdef.find('definition').text

        # Create FunctionNode instance
        function_node = FunctionNode(name, params, file, line, code, file_path)

        # Populate called_functions (from <references> tags)
        for ref in memberdef.findall('.//references'):
            called_function_name = ref.text
            function_node.called_functions.append(called_function_name)

        function_nodes.append(function_node)

    print(f"Parsed {len(function_nodes)} functions from {xml_file}")  # Debug print
    return function_nodes

def parse_doxygen_xml(directory):
    all_function_nodes = []
    for xml_file in os.listdir(directory):
        if xml_file.endswith(".xml"):
            xml_file_path = os.path.join(directory, xml_file)
            function_nodes = parse_file_xml(xml_file_path)
            all_function_nodes.extend(function_nodes)
    return all_function_nodes

def load_function_tree(pickle_file):
    try:
        with open(pickle_file, 'rb') as f:
            return pickle.load(f)
    except EOFError:
        print(f"Error: The pickle file {pickle_file} is empty or corrupted.")
        return None

def generate_function_graph(function_nodes, output_path):
    # Create a directed graph object using graphviz
    dot = graphviz.Digraph(comment='Function Call Graph', format='png')

    # Create a dictionary to map function names to their nodes
    node_map = {}

    # Add nodes for each function in the function tree
    for node in function_nodes:
        label = f"{node.name}\n{node.file}:{node.line}"
        dot.node(node.name, label)
        node_map[node.name] = node

    # Add edges based on function calls
    for node in function_nodes:
        for called_func in node.called_functions:
            if called_func in node_map:
                dot.edge(node.name, called_func)
            else:
                print(f"Warning: Called function {called_func} not found in the graph.")

    # Render the graph to a PNG file
    output_png = dot.render(output_path)
    print(f"Graph saved as {output_png}")

# Paths to the directories and files
xml_directory = r"D:\code\small_projects\docs\xml"
pickle_file_path = r'D:/code/small_projects/output_floder/function_tree.pkl'
output_png_path = r'D:/code/small_projects/output_floder/function_call_graph'

# Step 1: Parse the XML files and save the function nodes to a pickle file
function_nodes = parse_doxygen_xml(xml_directory)

# Save the function nodes to a pickle file
with open(pickle_file_path, 'wb') as f:
    pickle.dump(function_nodes, f)

print(f"Function tree saved to {pickle_file_path}")

# Step 2: Load the function tree from the pickle file and generate the function call graph
function_nodes = load_function_tree(pickle_file_path)

if function_nodes:
    # Generate the function call graph and save it as a PNG
    generate_function_graph(function_nodes, output_png_path)
else:
    print("No function nodes to process.")
