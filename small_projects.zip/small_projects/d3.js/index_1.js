<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Simple Collapsible Tree</title>
    <script src="https://d3js.org/d3.v7.min.js"></script>
    <style>
        .link {
            fill: none;
            stroke: #ccc;
            stroke-width: 2px;
        }
        .node circle {
            fill: #fff;
            stroke: steelblue;
            stroke-width: 3px;
        }
        .node text {
            font: 12px sans-serif;
        }
    </style>
</head>
<body>
    <svg width="600" height="400"></svg>
    <script>
        // Load the JSON data
        d3.json("functionData.json").then(function(data) {
            
            // Helper function to build the hierarchy
            function buildHierarchy(nodeName, allData) {
                let node = allData.find(d => d.name === nodeName);
                if (node) {
                    node.children = node.called_functions.map(fnName => buildHierarchy(fnName, allData)).filter(d => d !== null);
                    return node;
                }
                return null;
            }

            // Build the hierarchy starting from 'main'
            const rootData = buildHierarchy("main", data);  // Changed 'Parent' to 'main'

            if (!rootData) {
                console.error('Root data not found!');
                return;
            }

            const root = d3.hierarchy(rootData);

            const svg = d3.select("svg"),
                width = +svg.attr("width"),
                height = +svg.attr("height");

            const treeLayout = d3.tree().size([height, width - 160]);
            treeLayout(root);

            const g = svg.append("g").attr("transform", "translate(40,0)");

            // Links
            g.selectAll(".link")
                .data(root.links())
                .enter()
                .append("path")
                .attr("class", "link")
                .attr("d", d3.linkVertical()
                    .x(d => d.y)
                    .y(d => d.x));

            // Nodes
            const node = g.selectAll(".node")
                .data(root.descendants())
                .enter().append("g")
                .attr("class", d => "node" + (d.children ? " node--internal" : " node--leaf"))
                .attr("transform", d => `translate(${d.y},${d.x})`)
                .on("click", click);

            node.append("circle").attr("r", 4.5);
            node.append("text")
                .attr("dy", 3)
                .attr("x", d => d.children ? -8 : 8)
                .style("text-anchor", d => d.children ? "end" : "start")
                .text(d => d.data.name);

            function click(event, d) {
                // Toggle children on click
                if (d.children) {
                    d._children = d.children;
                    d.children = null;
                } else {
                    d.children = d._children;
                    d._children = null;
                }
                update(root);
            }

            function update(source) {
                const treeData = treeLayout(source);

                g.selectAll(".link")
                    .data(treeData.links())
                    .join("path")
                    .attr("class", "link")
                    .attr("d", d3.linkVertical()
                        .x(d => d.y)
                        .y(d => d.x));

                const nodeUpdate = g.selectAll(".node")
                    .data(treeData.descendants())
                    .join("g")
                    .attr("class", d => "node" + (d.children ? " node--internal" : " node--leaf"))
                    .attr("transform", d => `translate(${d.y},${d.x})`)
                    .on("click", click);

                nodeUpdate.select("circle").attr("r", 4.5);
                nodeUpdate.select("text")
                    .attr("dy", 3)
                    .attr("x", d => d.children ? -8 : 8)
                    .style("text-anchor", d => d.children ? "end" : "start")
                    .text(d => d.data.name);
            }
        }).catch(function(error) {
            console.error('Error loading the JSON data: ', error);
        });
    </script>
</body>
</html>
