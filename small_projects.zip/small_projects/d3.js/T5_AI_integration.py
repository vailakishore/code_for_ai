from transformers import AutoTokenizer, T5ForConditionalGeneration
import warnings

# Suppress FutureWarnings
warnings.filterwarnings("ignore", category=FutureWarning)

# Load the model and tokenizer
model_name = "Salesforce/codet5-base"  # Try 'codet5-large' if necessary
model = T5ForConditionalGeneration.from_pretrained(model_name)
tokenizer = AutoTokenizer.from_pretrained(model_name)

# Example input text with task-specific prompt
input_text = '''summarize: void process_array(int *arr, int size) {
    for (int i = 0; i < size - 1; i++) {
        for (int j = 0; j < size - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}'''

# Tokenize and prepare the input
inputs = tokenizer(input_text, return_tensors="pt")

# Generate text with increased max length for better output
outputs = model.generate(inputs['input_ids'], max_length=150)

# Decode the output
generated_text = tokenizer.decode(outputs[0], skip_special_tokens=True, clean_up_tokenization_spaces=False)

# Print the generated summary
print(generated_text)
