const width = window.innerWidth;
const height = window.innerHeight;
const svg = d3.select("#treeSvg").attr("width", width).attr("height", height);

const tooltip = d3.select("#tooltip");
const contextMenu = d3.select("#contextMenu");

// Define arrowhead marker
svg.append("defs").append("marker")
    .attr("id", "arrowhead")
    .attr("viewBox", "0 -5 10 10")
    .attr("refX", 13) // Control the placement of the arrowhead on the link
    .attr("refY", 0)
    .attr("markerWidth", 6)
    .attr("markerHeight", 6)
    .attr("orient", "auto")
    .append("path")
    .attr("d", "M0,-5L10,0L0,5")
    .attr("fill", "#999");

d3.json("functionData.json").then(function (data) {
    function buildHierarchy(nodeName, allData) {
        let node = allData.find(d => d.name === nodeName);
        if (node) {
            node.children = [];
            for (const fnName of node.called_functions) {
                if (fnName === nodeName) continue;
                const childNode = buildHierarchy(fnName, allData);
                if (childNode) node.children.push(childNode);
            }
            return node;
        }
        return null;
    }

    const rootData = buildHierarchy("main", data);
    if (!rootData) {
        console.error('Root data not found!');
        return;
    }

    let i = 0;
    const root = d3.hierarchy(rootData);
    root.x0 = height / 2;
    root.y0 = 0;

    const treeLayout = d3.tree().size([height - 100, width - 160]);
    const g = svg.append("g").attr("transform", "translate(40,0)");

    if (root.children) root.children.forEach(collapse);

    function update(source) {
        const treeData = treeLayout(root);
        const nodes = treeData.descendants();
        const links = treeData.links();

        nodes.forEach(d => { d.y = d.depth * 200; });

        const node = g.selectAll(".node")
            .data(nodes, d => d.id || (d.id = ++i));

        const nodeEnter = node.enter().append("g")
            .attr("class", "node")
            .attr("transform", d => `translate(${source.y0},${source.x0})`)
            .on("click", click)
            .on("mouseover", function (event, d) {
                tooltip.transition().duration(200).style("opacity", .9);
                tooltip.html("Function: " + d.data.name + "<br>File: " + d.data.file + "<br>Line: " + d.data.line)
                    .style("left", (event.pageX + 5) + "px")
                    .style("top", (event.pageY - 28) + "px");
            })
            .on("mouseout", function () {
                tooltip.transition().duration(500).style("opacity", 0);
            })
            .on("contextmenu", function (event, d) {
                event.preventDefault();
                const [x, y] = d3.pointer(event);
                contextMenu.style("display", "block")
                    .style("left", (event.pageX + 5) + "px")
                    .style("top", (event.pageY - 28) + "px");

                d3.selectAll(".context-menu-item").on("click", function () {
                    if (this.id === "option1") {
                        const filePath = d.data.file.replace(/\\/g, '/'); // Convert Windows path to proper format
                        const lineNumber = d.data.line; // Get the line number from data
                        const vscodeUrl = `vscode://file/${filePath}:${lineNumber}`;
                        window.location.href = vscodeUrl; // Redirect to open in VS Code
                    } else {
                        alert(`You selected ${this.textContent} for ${d.data.name}`);
                    }
                    contextMenu.style("display", "none");
                });
                    
                // d3.selectAll(".context-menu-item").on("click", function () {
                //     alert(`You selected ${this.textContent} for ${d.data.name}`);
                //     contextMenu.style("display", "none");
                // });
            });

        nodeEnter.append("ellipse")
            .attr("rx", function (d) {
                const textLength = d.data.name.length;
                return Math.max(20, textLength * 5); // Adjust the ellipse size dynamically
            })
            .attr("ry", 15)
            .attr("fill", d => d._children ? "lightsteelblue" : "#fff")
            .attr("stroke", "steelblue")
            .attr("stroke-width", "3px");

        nodeEnter.append("text")
            .attr("dy", "0.35em")
            .attr("x", 0)
            .style("text-anchor", "middle")
            .text(d => d.data.name);

        const nodeUpdate = node.merge(nodeEnter)
            .transition()
            .duration(200)
            .attr("transform", d => `translate(${d.y},${d.x})`);

        nodeUpdate.select("ellipse")
            .attr("rx", function (d) {
                const textLength = d.data.name.length;
                return Math.max(20, textLength * 5); // Adjust size based on text length during update
            })
            .attr("ry", 15);

        const nodeExit = node.exit().transition()
            .duration(200)
            .attr("transform", d => `translate(${source.y},${source.x})`)
            .remove();

        nodeExit.select("ellipse")
            .attr("rx", 1e-6)
            .attr("ry", 1e-6);

        const link = g.selectAll(".link")
            .data(links, d => d.target.id);

        link.enter().insert("path", "g")
            .attr("class", "link")
            .attr("d", d => {
                const o = { x: source.x0, y: source.y0 };
                return diagonal(o, o);
            })
            .attr("marker-end", "url(#arrowhead)");  // Add arrowhead marker

        link.transition()
            .duration(200)
            .attr("d", d => diagonal(d.source, d.target))
            .attr("marker-end", "url(#arrowhead)");  // Ensure arrowhead on transition

        link.exit().transition()
            .duration(200)
            .attr("d", d => {
                const o = { x: source.x, y: source.y };
                return diagonal(o, o);
            })
            .remove();

        nodes.forEach(d => {
            d.x0 = d.x;
            d.y0 = d.y;
        });

        function diagonal(s, d) {
            return `M${s.y},${s.x}C${(s.y + d.y ) / 2},${s.x} ${(s.y + d.y) / 2},${d.x} ${d.y},${d.x}`;
        }

        function click(event, d) {
            if (d.children) {
                d._children = d.children;
                d.children = null;
            } else {
                d.children = d._children;
                d._children = null;
            }
            update(d);
        }
    }

    function collapse(d) {
        if (d.children) {
            d._children = d.children;
            d._children.forEach(collapse);
            d.children = null;
        }
    }

    update(root);

    svg.on("click", function () {
        contextMenu.style("display", "none");
    });

}).catch(function (error) {
    console.error('Error loading the JSON file:', error);
});
