import requests

# Replace 'YOUR_API_KEY' with your Hugging Face API token
API_KEY = "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"
API_URL = "https://api-inference.huggingface.co/models/Salesforce/codet5-base"

headers = {"Authorization": f"Bearer {API_KEY}"}

# Provide the code and explicitly ask for a concise description
code_input = {
    "inputs": '''Explain the following C function in detail.

Example 1:
Function: int add(int a, int b)
Explanation: This function takes two integers and returns their sum.

Example 2:
Function: void process_array(int *arr, int size)
Explanation: This function takes a pointer to an integer array and its size, sorts the array, and calculates the factorial of the first element and the Fibonacci of the second element.

Now, explain the following function:
void process_array(int *arr, int size) {
    // Example operation: sorting the array
    for (int i = 0; i < size - 1; i++) {
        for (int j = 0; j < size - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
    int fact = factorial(arr[0]);
    int fib = fibonacci(arr[1]);
    reverse_string(str);
}'''
}


# Make the API request
response = requests.post(API_URL, headers=headers, json=code_input)

# Extract the generated text from the JSON response
generated_text = response.json()[0]["generated_text"]

# Isolate and clean the description
description = generated_text.split("Description")[1] if "Description" in generated_text else generated_text
description = description.strip()

# Specify the file name to save the description
file_name = "D:\code\small_projects\d3.js\hugging_face_AI\code_description.txt"

# Open the file in write mode and write the description
with open(file_name, "w") as file:
    file.write(description)

# Notify the user that the data has been written
print(f"Description has been written to {file_name}.")
